#!/usr/bin/env python3
"""
Serwer trybu NA ŻYWO. Działa w chmurze (np. Render), a Ty wchodzisz z telefonu przez link.
Co robi: co REFRESH_MIN pobiera prawdziwe kursy (The Odds API), liczy model Poissona
(football-data.org), co SCORES_MIN pobiera wyniki na żywo. Klucze zostają na serwerze.
Wymaga w tym samym folderze: bot_ev.py i index.html. Start: python server.py
"""
import os, json, time, zlib, threading, urllib.request, urllib.parse, datetime as dt
from pathlib import Path
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

os.environ.setdefault("DB_PATH", ":memory:")
os.environ.setdefault("TELEGRAM_BOT_TOKEN", "")
import bot_ev as B

REFRESH = float(os.environ.get("REFRESH_MIN", "120")) * 60
SCORES = float(os.environ.get("SCORES_MIN", "5")) * 60
USE = [c.strip() for c in os.environ.get("LEAGUES", ",".join(B.LEAGUES)).split(",") if c.strip() in B.LEAGUES]
TENNIS = os.environ.get("TENNIS", "1") == "1"
DATA = {"m": {}, "upd": 0, "err": "", "quota": None}
STR = {}
LK = threading.Lock()


def oget(path, **q):
    q["apiKey"] = B.ODDS_KEY
    url = "https://api.the-odds-api.com/v4" + path + "?" + urllib.parse.urlencode(q)
    with urllib.request.urlopen(url, timeout=25) as r:
        DATA["quota"] = r.headers.get("x-requests-remaining")
        return json.loads(r.read())


def strengths(code):
    t = STR.get(code)
    if not t or time.time() - t[0] > 21600:  # model przeliczany co 6 h
        s = B.team_strengths(B.fd(f"/competitions/{code}/matches?status=FINISHED")["matches"])
        STR[code] = (time.time(), s)
        time.sleep(7)  # limit darmowego football-data: 10 zapytan/min
    return STR[code][1]


def minutes(e):
    return dt.datetime.fromisoformat(e["commence_time"].replace("Z", "+00:00")).timestamp() / 60


def build_event(e, league, sport, st, tennis):
    best, cons = B.best_prices(e)
    ks = [k for k in best if k in cons]
    if not ks:
        return None
    m = dict(id=zlib.crc32(e["id"].encode()), K=minutes(e), league=league, sport=sport,
             home=e["home_team"], away=e["away_team"], done=False, len=180 if tennis else 100)
    if tennis:
        ren = {"1": "P1", "2": "P2"}
        m.update(type="t", odds={ren[k]: best[k][0] for k in ks if k in ren},
                 bk={ren[k]: best[k][1] for k in ks if k in ren}, mp={ren[k]: cons[k] for k in ks if k in ren})
        if len(m["odds"]) < 2:
            return None
    else:
        mp = {k: cons[k] for k in ks}
        m.update(type="f", odds={k: best[k][0] for k in ks}, bk={k: best[k][1] for k in ks})
        if st:
            h = B.match_team(e["home_team"], list(st[2]))
            a = B.match_team(e["away_team"], list(st[2]))
            xg = B.expected_goals(st, h, a) if h and a else None
            if xg:
                pr = B.market_probs(*xg)
                w = B.MARKET_WEIGHT
                mp = {k: (1 - w) * pr[k] + w * cons[k] for k in ks}
                m.update(lh=xg[0], la=xg[1], avg=[st[0], st[1]], mpm=pr, mpk=cons,
                         H=dict(a=st[2][h]["att_h"], d=st[2][h]["def_h"]),
                         A=dict(a=st[2][a]["att_a"], d=st[2][a]["def_a"]))
        m["mp"] = mp
    m["close"] = dict(m["odds"])
    return m


def refresh_odds():
    new, errs = {}, []
    for code in USE:
        name, sport = B.LEAGUES[code]
        try:
            st = strengths(code)
        except Exception as ex:
            st = None
            errs.append(f"{code} model: {ex}")
        try:
            for e in oget(f"/sports/{sport}/odds", regions="eu", markets="h2h,totals", oddsFormat="decimal"):
                m = build_event(e, name, sport, st, False)
                if m:
                    new[m["id"]] = m
        except Exception as ex:
            errs.append(f"{code} kursy: {ex}")
    if TENNIS:
        try:
            for sp in oget("/sports"):  # lista sportow jest darmowa
                if sp.get("active") and sp["key"].startswith("tennis_"):
                    for e in oget(f"/sports/{sp['key']}/odds", regions="eu", markets="h2h", oddsFormat="decimal"):
                        m = build_event(e, sp["title"], sp["key"], None, True)
                        if m:
                            new[m["id"]] = m
        except Exception as ex:
            errs.append(f"tenis: {ex}")
    now = time.time() / 60
    with LK:
        old = DATA["m"]
        for i, m in new.items():
            o = old.get(i)
            if o:
                m.update(done=o["done"], sc=o.get("sc"), win=o.get("win"), final=o.get("final"))
                if now >= o["K"]:  # mecz ruszyl: zamrazamy kursy = kurs zamkniecia (do CLV)
                    m.update(odds=o["odds"], mp=o["mp"], bk=o["bk"], close=o["odds"])
            old[i] = m
        for i in [i for i, m in old.items() if m["K"] < now - 2880]:
            del old[i]
        DATA.update(upd=time.time(), err="; ".join(errs))


def refresh_scores():
    now = time.time() / 60
    with LK:
        sports = {m["sport"] for m in DATA["m"].values() if not m["done"] and m["K"] < now}
    for sp in sports:
        try:
            evs = oget(f"/sports/{sp}/scores", daysFrom=3)
        except Exception as ex:
            DATA["err"] = f"wyniki: {ex}"
            continue
        with LK:
            for e in evs:
                m = DATA["m"].get(zlib.crc32(e["id"].encode()))
                if not m or not e.get("scores"):
                    continue
                try:
                    sc = {x["name"]: int(x["score"]) for x in e["scores"]}
                except Exception:
                    continue
                h, a = sc.get(e["home_team"]), sc.get(e["away_team"])
                if h is None or a is None:
                    continue
                m["sc"] = [h, a]
                if e.get("completed"):
                    m.update(done=True, final=[h, a], win=1 if h > a else 2 if a > h else 0)


def loop():
    t_o = t_s = 0
    while True:
        n = time.time()
        try:
            if n - t_o >= REFRESH:
                t_o = n
                refresh_odds()
            if n - t_s >= SCORES:
                t_s = n
                refresh_scores()
        except Exception as ex:
            DATA["err"] = str(ex)
        time.sleep(15)


def snap():
    with LK:
        ms = sorted(DATA["m"].values(), key=lambda m: m["K"])
    return {"matches": ms, "updated": DATA["upd"], "error": DATA["err"], "quota": DATA["quota"]}


class H(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith("/api/live"):
            body, ct = json.dumps(snap()).encode(), "application/json; charset=utf-8"
        else:
            body, ct = Path(__file__).with_name("index.html").read_bytes(), "text/html; charset=utf-8"
        self.send_response(200)
        self.send_header("Content-Type", ct)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *a):
        pass


if __name__ == "__main__":
    if not B.ODDS_KEY or not B.FD_KEY:
        raise SystemExit("Ustaw ODDS_API_KEY i FOOTBALL_DATA_API_KEY (zmienne srodowiskowe lub .env)")
    threading.Thread(target=loop, daemon=True).start()
    port = int(os.environ.get("PORT", "8000"))
    print(f"Serwer na porcie {port}; ligi: {USE}; kursy co {REFRESH / 60:.0f} min")
    ThreadingHTTPServer(("", port), H).serve_forever()
