# Wdrożenie wersji NA ŻYWO (działa z telefonu, bez komputera)

## Co dostajesz
Jedna strona pod Twoim linkiem: **Na żywo** (prawdziwe mecze, kursy i wyniki, kupony rozliczane po prawdziwych wynikach) oraz **Trening** (demo ze starymi/wygenerowanymi meczami i szybkim zegarem). Dwa osobne konta po 500 zł, zapisywane w przeglądarce telefonu.

Pliki: `server.py`, `bot_ev.py`, `index.html` (wszystkie w jednym folderze, razem).

## 0. Najpierw nowe klucze
Poprzednie (token Telegrama, klucz football-data, URL Apps Script) wyciekły w czacie z Gemini. Wygeneruj nowe. Szczegóły w README do bota.

## 1. Klucze API
- **The Odds API** (the-odds-api.com): kursy i wyniki. Darmowy plan to tylko ok. 500 „kredytów” miesięcznie.
- **football-data.org**: dane do modelu (darmowy klucz wystarczy).

## 2. Hosting (Render.com, darmowy start)
1. Załóż konto na GitHub i wrzuć repozytorium z trzema plikami.
2. Render → New → **Web Service** → wskaż repozytorium.
3. Runtime: **Python**, Build Command: `echo ok`, Start Command: `python server.py`.
4. Environment (zmienne): `ODDS_API_KEY`, `FOOTBALL_DATA_API_KEY`, opcjonalnie `LEAGUES`, `REFRESH_MIN`, `SCORES_MIN`, `TENNIS`.
5. Po wdrożeniu dostajesz link `https://twoja-nazwa.onrender.com`. Otwórz go w telefonie → „Dodaj do ekranu głównego”.

## 3. Limity kredytów (ważne)
Jedno odświeżenie kursów jednej ligi = 2 kredyty, tenis ok. 1 na turniej, wyniki 2 na sport przy każdym sprawdzeniu.
- **Plan darmowy (500/mies.):** ustaw `LEAGUES=PL`, `TENNIS=0`, `REFRESH_MIN=240`, `SCORES_MIN=15`. Wystarczy na jedną ligę, bez „ciągłego” live.
- **Wszystkie 5 lig + tenis, odświeżanie co godzinę:** potrzebny płatny plan The Odds API (ok. 30 USD/mies., 20 tys. kredytów).
Serwer trzyma dane w pamięci i wszyscy użytkownicy dzielą jedno odświeżanie, więc otwieranie strony nie zużywa kredytów.

## 4. Co trzeba wiedzieć
- Render darmowy **usypia serwer po 15 min bezczynności**: pierwsze wejście trwa ok. minuty, a w czasie snu dane się nie odświeżają. Rozliczanie kuponów dzieje się w przeglądarce, gdy aplikacja jest otwarta, więc kupon rozliczy się przy następnym wejściu (serwer pamięta mecze 48 h).
- Rynki w trybie Na żywo: 1X2 i powyżej/poniżej 2.5 gola (tyle daje zwykły plan API). Dodatkowe rynki (BTTS, podwójna szansa, progi 1.5/3.5) są w Treningu.
- Tenis na żywo nie ma modelu, tylko konsensus rynku („line shopping”). To słabszy sygnał niż w piłce.
- Czas rozpoczęcia meczu i minuty są przybliżone (przerwy nie są liczone).
- To nadal paper trading. Strona nie obsługuje prawdziwych pieniędzy.
