#!/usr/bin/env python3
"""
Bot EV+ (paper trading) - wersja 2.0
- prawdziwy model Poissona liczony z wynikow ostatnich meczow (football-data.org)
- prawdziwe kursy (The Odds API) -> EV liczone na realnych cenach, nie wymyslonych
- baza SQLite (nic nie ginie po restarcie), automatyczne rozliczanie typow
- sekrety w pliku .env, nie w kodzie. Tylko biblioteka standardowa Pythona.

Komendy: /scan /wallet /stats /pending /settle /help
"""
import os, json, math, time, sqlite3, difflib, html
import urllib.request, urllib.parse, urllib.error
import datetime as dt
from pathlib import Path


# ------------------------------------------------------------------ config
def load_env(path=".env"):
    p = Path(path)
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


load_env()
TG_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")
FD_KEY = os.environ.get("FOOTBALL_DATA_API_KEY", "")
ODDS_KEY = os.environ.get("ODDS_API_KEY", "")
ALLOWED_CHAT = os.environ.get("ALLOWED_CHAT_ID", "")      # tylko Ty mozesz sterowac botem
SHEETS_URL = os.environ.get("GOOGLE_SHEETS_WEBAPP_URL", "")  # opcjonalnie
START_BANKROLL = float(os.environ.get("START_BANKROLL", "500"))
MIN_EV = float(os.environ.get("MIN_EV", "0.05"))           # min. przewaga 5%
MAX_EV = float(os.environ.get("MAX_EV", "0.25"))           # powyzej = podejrzane (blad danych)
KELLY_FRACTION = float(os.environ.get("KELLY_FRACTION", "0.25"))
MAX_STAKE_PCT = float(os.environ.get("MAX_STAKE_PCT", "0.03"))
MARKET_WEIGHT = float(os.environ.get("MARKET_WEIGHT", "0.5"))  # ile ufamy konsensusowi rynku
DAYS_AHEAD = int(os.environ.get("DAYS_AHEAD", "3"))
MAX_ALERTS = int(os.environ.get("MAX_ALERTS", "5"))
AUTO_SCAN_HOURS = float(os.environ.get("AUTO_SCAN_HOURS", "0"))  # 0 = tylko reczne /scan
DB_PATH = os.environ.get("DB_PATH", "bot_ev.db")

LEAGUES = {  # kod football-data : (nazwa, klucz The Odds API)
    "PL": ("Premier League", "soccer_epl"),
    "PD": ("La Liga", "soccer_spain_la_liga"),
    "BL1": ("Bundesliga", "soccer_germany_bundesliga"),
    "SA": ("Serie A", "soccer_italy_serie_a"),
    "FL1": ("Ligue 1", "soccer_france_ligue_one"),
}
TG = f"https://api.telegram.org/bot{TG_TOKEN}"


# ------------------------------------------------------------------ http
def http_json(url, headers=None, data=None, timeout=25):
    req = urllib.request.Request(url, headers=headers or {}, data=data)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def tg(method, **params):
    try:
        return http_json(f"{TG}/{method}", data=urllib.parse.urlencode(params).encode(), timeout=40)
    except Exception as e:
        print(f"[telegram:{method}] {e}")
        return None


def send(chat_id, text, keyboard=None):
    p = dict(chat_id=chat_id, text=text, parse_mode="HTML")
    if keyboard:
        p["reply_markup"] = json.dumps(keyboard)
    return tg("sendMessage", **p)


def fd(path):
    return http_json(f"https://api.football-data.org/v4{path}", {"X-Auth-Token": FD_KEY})


# ------------------------------------------------------------------ database
db = sqlite3.connect(DB_PATH, check_same_thread=False)
db.executescript("""
CREATE TABLE IF NOT EXISTS signals(id INTEGER PRIMARY KEY, created TEXT, data TEXT);
CREATE TABLE IF NOT EXISTS bets(
  id INTEGER PRIMARY KEY, created TEXT, match_id INTEGER, match TEXT, comp TEXT,
  market TEXT, label TEXT, odds REAL, prob REAL, ev REAL, stake REAL,
  status TEXT DEFAULT 'pending', pnl REAL DEFAULT 0, settled TEXT);
""")


def now():
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M")


def bankroll():
    pnl = db.execute("SELECT COALESCE(SUM(pnl),0) FROM bets WHERE status IN ('won','lost')").fetchone()[0]
    open_ = db.execute("SELECT COALESCE(SUM(stake),0) FROM bets WHERE status='pending'").fetchone()[0]
    return START_BANKROLL + pnl - open_


# ------------------------------------------------------------------ model
def pois(k, lam):
    return math.exp(-lam) * lam ** k / math.factorial(k)


def market_probs(lh, la, n=11):
    """Rozklad Poissona dla goli -> prawdopodobienstwa rynkow 1X2 i O/U 2.5."""
    p1 = px = p2 = over = tot = 0.0
    for i in range(n):
        for j in range(n):
            p = pois(i, lh) * pois(j, la)
            tot += p
            if i > j: p1 += p
            elif i == j: px += p
            else: p2 += p
            if i + j > 2: over += p
    return {"1": p1 / tot, "X": px / tot, "2": p2 / tot, "O2.5": over / tot, "U2.5": 1 - over / tot}


def team_strengths(matches, shrink=5):
    """Sila ataku/obrony dom/wyjazd z zakonczonych meczow, sciagana do sredniej (shrink)."""
    rows = [(m["homeTeam"]["name"], m["awayTeam"]["name"],
             m["score"]["fullTime"]["home"], m["score"]["fullTime"]["away"])
            for m in matches if m["score"]["fullTime"]["home"] is not None]
    if len(rows) < 30:
        return None
    avg_h = sum(r[2] for r in rows) / len(rows)
    avg_a = sum(r[3] for r in rows) / len(rows)
    st = {}
    for h, a, gh, ga in rows:
        for t in (h, a):
            st.setdefault(t, dict(hn=0, hgf=0, hga=0, an=0, agf=0, aga=0))
        st[h]["hn"] += 1; st[h]["hgf"] += gh; st[h]["hga"] += ga
        st[a]["an"] += 1; st[a]["agf"] += ga; st[a]["aga"] += gh
    out = {}
    for t, s in st.items():
        out[t] = dict(
            n=s["hn"] + s["an"],
            att_h=(s["hgf"] + shrink * avg_h) / ((s["hn"] + shrink) * avg_h),
            def_h=(s["hga"] + shrink * avg_a) / ((s["hn"] + shrink) * avg_a),
            att_a=(s["agf"] + shrink * avg_a) / ((s["an"] + shrink) * avg_a),
            def_a=(s["aga"] + shrink * avg_h) / ((s["an"] + shrink) * avg_h),
        )
    return avg_h, avg_a, out


def expected_goals(strengths, home, away):
    avg_h, avg_a, t = strengths
    if home not in t or away not in t or t[home]["n"] < 6 or t[away]["n"] < 6:
        return None
    lh = avg_h * t[home]["att_h"] * t[away]["def_a"]
    la = avg_a * t[away]["att_a"] * t[home]["def_h"]
    return lh, la


# ------------------------------------------------------------------ odds
def norm(name):
    n = name.lower()
    for w in (" fc", "fc ", " cf", "afc ", " afc", "ac ", " ac", "as ", " as", "us ", "1. ", "rc ", "sc ", "real ", "club "):
        n = n.replace(w, " ")
    return " ".join(n.split())


def match_team(name, candidates):
    best = difflib.get_close_matches(norm(name), [norm(c) for c in candidates], n=1, cutoff=0.6)
    if not best:
        return None
    for c in candidates:
        if norm(c) == best[0]:
            return c


def fetch_odds(sport_key):
    q = urllib.parse.urlencode(dict(apiKey=ODDS_KEY, regions="eu", markets="h2h,totals", oddsFormat="decimal"))
    return http_json(f"https://api.the-odds-api.com/v4/sports/{sport_key}/odds?{q}")


def best_prices(event):
    """Najlepsze ceny per wynik + konsensus rynku bez marzy (no-vig)."""
    best, consensus = {}, {}
    for bk in event["bookmakers"]:
        for mk in bk["markets"]:
            outs = {}
            for o in mk["outcomes"]:
                if mk["key"] == "h2h":
                    key = "X" if o["name"] == "Draw" else ("1" if o["name"] == event["home_team"] else "2")
                elif mk["key"] == "totals" and abs(o.get("point", 0) - 2.5) < 1e-9:
                    key = "O2.5" if o["name"] == "Over" else "U2.5"
                else:
                    continue
                outs[key] = o["price"]
            if len(outs) in (2, 3):
                inv = sum(1 / p for p in outs.values())
                for k, p in outs.items():
                    consensus.setdefault(k, []).append((1 / p) / inv)
                    if p > best.get(k, (0, ""))[0]:
                        best[k] = (p, bk["title"])
    cons = {k: sum(v) / len(v) for k, v in consensus.items() if len(v) >= 3}
    return best, cons


LABELS = {"X": "Remis", "O2.5": "Powyzej 2.5 gola", "U2.5": "Ponizej 2.5 gola"}


def label_for(key, home, away):
    """Opis typu: 'Wygrana <nazwa druzyny>' zamiast 'gospodarzy/gosci'."""
    if key == "1":
        return f"Wygrana {home}"
    if key == "2":
        return f"Wygrana {away}"
    return LABELS[key]


def kelly_stake(prob, odds):
    k = (prob * odds - 1) / (odds - 1)
    pct = min(max(k, 0) * KELLY_FRACTION, MAX_STAKE_PCT)
    return round(bankroll() * pct)


def scan():
    """Zwraca liste sygnalow EV+ (posortowana malejaco po EV)."""
    if not ODDS_KEY:
        raise RuntimeError("Brak ODDS_API_KEY w .env (darmowy klucz: the-odds-api.com)")
    today = dt.date.today()
    d_to = today + dt.timedelta(days=DAYS_AHEAD)
    signals = []
    for code, (lname, sport) in LEAGUES.items():
        try:
            finished = fd(f"/competitions/{code}/matches?status=FINISHED")["matches"]
            st = team_strengths(finished)
            if not st:
                print(f"[{code}] za malo meczow do modelu"); continue
            time.sleep(6)  # limit free: 10 req/min
            upcoming = fd(f"/competitions/{code}/matches?status=SCHEDULED&dateFrom={today}&dateTo={d_to}")["matches"]
            events = fetch_odds(sport)
            time.sleep(6)
        except Exception as e:
            print(f"[{code}] blad: {e}"); continue
        for m in upcoming:
            h, a = m["homeTeam"]["name"], m["awayTeam"]["name"]
            xg = expected_goals(st, h, a)
            if not xg:
                continue
            ev_h = match_team(h, [e["home_team"] for e in events])
            ev_a = match_team(a, [e["away_team"] for e in events])
            event = next((e for e in events if e["home_team"] == ev_h and e["away_team"] == ev_a), None)
            if not event:
                continue
            probs = market_probs(*xg)
            best, cons = best_prices(event)
            for key, (odds, bookie) in best.items():
                if key not in cons:
                    continue
                p = (1 - MARKET_WEIGHT) * probs[key] + MARKET_WEIGHT * cons[key]
                ev = p * odds - 1
                if MIN_EV <= ev <= MAX_EV:
                    stake = kelly_stake(p, odds)
                    if stake >= 1:
                        signals.append(dict(match_id=m["id"], match=f"{h} vs {a}", comp=lname,
                                            date=m["utcDate"][:16].replace("T", " "), market=key,
                                            label=label_for(key, h, a), odds=odds, bookie=bookie, prob=p,
                                            model=probs[key], mkt=cons[key], ev=ev, stake=stake,
                                            xg=f"{xg[0]:.2f}:{xg[1]:.2f}"))
    signals.sort(key=lambda s: -s["ev"])
    return signals


# ------------------------------------------------------------------ settlement
def outcome_won(market, gh, ga):
    return {"1": gh > ga, "X": gh == ga, "2": gh < ga,
            "O2.5": gh + ga > 2, "U2.5": gh + ga < 3}[market]


def settle_pending():
    rows = db.execute("SELECT id, match_id, market, odds, stake FROM bets WHERE status='pending'").fetchall()
    done = []
    for bid, mid, market, odds, stake in rows:
        try:
            m = fd(f"/matches/{mid}")
            time.sleep(6)
        except Exception as e:
            print(f"[settle {mid}] {e}"); continue
        if m.get("status") != "FINISHED":
            continue
        ft = m["score"]["fullTime"]
        won = outcome_won(market, ft["home"], ft["away"])
        pnl = round(stake * (odds - 1), 2) if won else -stake
        db.execute("UPDATE bets SET status=?, pnl=?, settled=? WHERE id=?",
                   ("won" if won else "lost", pnl, now(), bid))
        db.commit()
        done.append((bid, m["homeTeam"]["name"], m["awayTeam"]["name"], ft["home"], ft["away"], won, pnl))
    return done


def stats_text():
    r = db.execute("""SELECT COUNT(*), COALESCE(SUM(status='won'),0), COALESCE(SUM(stake),0),
                      COALESCE(SUM(pnl),0), COALESCE(AVG(odds),0) FROM bets
                      WHERE status IN ('won','lost')""").fetchone()
    n, w, staked, pnl, avg_odds = r
    pend = db.execute("SELECT COUNT(*) FROM bets WHERE status='pending'").fetchone()[0]
    yld = pnl / staked * 100 if staked else 0
    txt = (f"📊 <b>STATYSTYKI (paper trading)</b>\n\n"
           f"💼 Bankroll: <code>{bankroll():.2f} zl</code> (start {START_BANKROLL:.0f})\n"
           f"✅ Rozliczone: {n} (wygrane {w}, hit rate {w / n * 100 if n else 0:.1f}%)\n"
           f"⏳ Otwarte: {pend}\n"
           f"📈 Yield: <code>{yld:+.1f}%</code> | Zysk: <code>{pnl:+.2f} zl</code>\n"
           f"🎲 Sredni kurs: {avg_odds:.2f}")
    if n < 100:
        txt += f"\n\n⚠️ Proba {n}/100 typow - to jeszcze szum statystyczny, nie wyciagaj wnioskow."
    return txt


# ------------------------------------------------------------------ sheets (opcjonalnie)
def to_sheets(row):
    if not SHEETS_URL:
        return
    try:
        http_json(SHEETS_URL, {"Content-Type": "application/json"}, json.dumps(row).encode(), 15)
    except Exception as e:
        print(f"[sheets] {e}")


# ------------------------------------------------------------------ handlers
def do_scan(chat_id):
    send(chat_id, "🔍 Skanuje ligi (ok. minuty - limity darmowych API)...")
    try:
        sigs = scan()
    except Exception as e:
        send(chat_id, f"❌ Blad skanowania: {html.escape(str(e))}"); return
    if not sigs:
        send(chat_id, "Brak typow z przewaga w zadanym przedziale. To normalne - wiekszosc dni nic nie ma.")
        return
    send(chat_id, f"Znaleziono {len(sigs)} typow, pokazuje top {min(len(sigs), MAX_ALERTS)}:")
    for s in sigs[:MAX_ALERTS]:
        sid = db.execute("INSERT INTO signals(created,data) VALUES(?,?)", (now(), json.dumps(s))).lastrowid
        db.commit()
        txt = (f"⚽ <b>{html.escape(s['match'])}</b>\n🏆 {s['comp']} | 🕒 {s['date']} UTC\n"
               f"🎯 <b>{s['label']}</b> @ <code>{s['odds']}</code> ({html.escape(s['bookie'])})\n"
               f"📈 EV: <code>{s['ev'] * 100:+.1f}%</code> | p: {s['prob'] * 100:.1f}% "
               f"(model {s['model'] * 100:.1f}% / rynek {s['mkt'] * 100:.1f}%)\n"
               f"⚙️ xG modelu: {s['xg']}\n💰 Stawka: <code>{s['stake']} zl</code>")
        kb = {"inline_keyboard": [[{"text": "🟢 Zagraj na sucho", "callback_data": f"dry:{sid}"},
                                   {"text": "🔴 Odrzuc", "callback_data": f"no:{sid}"}]]}
        send(chat_id, txt, kb)


def do_callback(cq):
    chat_id = cq["message"]["chat"]["id"]
    msg_id = cq["message"]["message_id"]
    tg("answerCallbackQuery", callback_query_id=cq["id"])
    action, sid = cq["data"].split(":")
    row = db.execute("SELECT data FROM signals WHERE id=?", (sid,)).fetchone()
    if not row:
        return
    s = json.loads(row[0])
    base = cq["message"]["text"]
    if action == "dry":
        if db.execute("SELECT 1 FROM bets WHERE match_id=? AND market=?", (s["match_id"], s["market"])).fetchone():
            tg("editMessageText", chat_id=chat_id, message_id=msg_id, text=base + "\n\n⚠️ Ten typ juz zagrany.")
            return
        db.execute("""INSERT INTO bets(created,match_id,match,comp,market,label,odds,prob,ev,stake)
                      VALUES(?,?,?,?,?,?,?,?,?,?)""",
                   (now(), s["match_id"], s["match"], s["comp"], s["market"], s["label"],
                    s["odds"], s["prob"], s["ev"], s["stake"]))
        db.commit()
        to_sheets(dict(mecz=s["match"], rynek=s["label"], kurs=s["odds"], stawka=s["stake"], status="na sucho"))
        tg("editMessageText", chat_id=chat_id, message_id=msg_id, text=base + "\n\n✅ Zapisano (na sucho).")
    else:
        tg("editMessageText", chat_id=chat_id, message_id=msg_id, text=base + "\n\n❌ Odrzucono.")


def do_settle(chat_id):
    send(chat_id, "🧾 Rozliczam zakonczone mecze...")
    done = settle_pending()
    if not done:
        send(chat_id, "Nic nowego do rozliczenia."); return
    for bid, h, a, gh, ga, won, pnl in done:
        send(chat_id, f"{'✅' if won else '❌'} {html.escape(h)} {gh}:{ga} {html.escape(a)}  →  <code>{pnl:+.2f} zl</code>")
    send(chat_id, stats_text())


def do_pending(chat_id):
    rows = db.execute("SELECT match, label, odds, stake FROM bets WHERE status='pending'").fetchall()
    if not rows:
        send(chat_id, "Brak otwartych typow."); return
    send(chat_id, "⏳ <b>Otwarte typy:</b>\n" +
         "\n".join(f"• {html.escape(m)} — {l} @ {o} ({s:.0f} zl)" for m, l, o, s in rows))


HELP = ("🤖 <b>Bot EV+ v2 (paper trading)</b>\n\n/scan – szukaj typow z przewaga\n/pending – otwarte typy\n"
        "/settle – rozlicz zakonczone mecze\n/wallet lub /stats – wyniki\n\n"
        "Model: Poisson z wynikow ligowych + konsensus rynku. Dziala tylko na sucho.")


def handle(update):
    if "callback_query" in update:
        cq = update["callback_query"]
        if not ALLOWED_CHAT or str(cq["message"]["chat"]["id"]) == ALLOWED_CHAT:
            do_callback(cq)
        return
    msg = update.get("message")
    if not msg:
        return
    chat_id = msg["chat"]["id"]
    if ALLOWED_CHAT and str(chat_id) != ALLOWED_CHAT:
        send(chat_id, f"Brak dostepu. Twoje chat_id: {chat_id}")
        return
    cmd = msg.get("text", "").split()[0].split("@")[0] if msg.get("text") else ""
    if cmd in ("/start", "/help"): send(chat_id, HELP + f"\n\nchat_id: <code>{chat_id}</code>")
    elif cmd == "/scan": do_scan(chat_id)
    elif cmd == "/settle": do_settle(chat_id)
    elif cmd == "/pending": do_pending(chat_id)
    elif cmd in ("/wallet", "/stats"): send(chat_id, stats_text())


def main():
    if not TG_TOKEN or not FD_KEY:
        raise SystemExit("Uzupelnij TELEGRAM_BOT_TOKEN i FOOTBALL_DATA_API_KEY w pliku .env")
    print("Bot EV+ v2 wystartowal. Ctrl+C aby zatrzymac.")
    offset, last_settle, last_scan = 0, time.time(), time.time()
    while True:
        try:
            res = tg("getUpdates", offset=offset, timeout=25)
            for u in (res or {}).get("result", []):
                offset = u["update_id"] + 1
                try:
                    handle(u)
                except Exception as e:
                    print(f"[handle] {e}")
            if ALLOWED_CHAT and time.time() - last_settle > 1800:
                last_settle = time.time()
                if db.execute("SELECT 1 FROM bets WHERE status='pending'").fetchone():
                    do_settle(ALLOWED_CHAT)
            if ALLOWED_CHAT and AUTO_SCAN_HOURS and time.time() - last_scan > AUTO_SCAN_HOURS * 3600:
                last_scan = time.time()
                do_scan(ALLOWED_CHAT)
        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"[loop] {e}")
            time.sleep(5)


if __name__ == "__main__":
    main()
